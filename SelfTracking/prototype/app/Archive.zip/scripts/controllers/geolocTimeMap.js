'use strict';

angular.module('frontEndApp')
  .controller('GeoloctimemapCtrl', function ($scope) {

  });
